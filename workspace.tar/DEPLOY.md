# 🚀 Quick Start: Deploy PodCaster to AWS

## Choose Your Deployment Method

### 🎯 **Option 1: AWS Amplify (Easiest - 5 minutes)**
**Best for:** Quick deployment, automatic CI/CD, no AWS expertise needed

```bash
# 1. Push to GitHub
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/podcaster.git
git push -u origin main

# 2. Go to AWS Amplify Console
# https://console.aws.amazon.com/amplify/

# 3. Click "New app" → "Host web app"
# 4. Connect your GitHub repo
# 5. Deploy! (amplify.yml is already configured)
```

**Result:** Your app will be live at `https://main.xxxxx.amplifyapp.com`

---

### 💰 **Option 2: S3 + CloudFront (Most Cost-Effective)**
**Best for:** Production static sites, lowest cost (~$0.50/month)

```bash
# 1. Install AWS CLI
# https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html

# 2. Configure AWS credentials
aws configure

# 3. Create S3 bucket
aws s3api create-bucket --bucket podcaster-app --region us-east-1

# 4. Enable static website hosting
aws s3 website s3://podcaster-app/ \
    --index-document index.html \
    --error-document index.html

# 5. Apply bucket policy
aws s3api put-bucket-policy \
    --bucket podcaster-app \
    --policy file://s3-policy.json

# 6. Deploy using the script
chmod +x aws-deploy.sh
./aws-deploy.sh podcaster-app
```

**Result:** Your app will be at `https://podcaster-app.s3.us-east-1.amazonaws.com`

**Optional:** Add CloudFront for HTTPS and CDN (see AWS-DEPLOYMENT.md)

---

### 🖥️ **Option 3: EC2 + Nginx (Full Control)**
**Best for:** When you need server-side features or custom configurations

Follow the detailed steps in `AWS-DEPLOYMENT.md` under "Option 3: EC2 + Nginx"

---

## 📋 What You Need

### For All Options:
- ✅ AWS Account
- ✅ AWS CLI installed (`aws configure`)
- ✅ Node.js 18+ installed

### For Amplify:
- ✅ GitHub/GitLab/Bitbucket account
- ✅ Your code pushed to Git

### For S3 + CloudFront:
- ✅ S3 bucket created
- ✅ Bucket policy applied (use `s3-policy.json`)

### For EC2:
- ✅ EC2 instance running
- ✅ Nginx installed
- ✅ Security groups configured (ports 80, 443)

---

## 🔄 Automated Deployment (GitHub Actions)

The `.github/workflows/deploy.yml` file is already configured!

**Setup:**
1. Go to your GitHub repo → Settings → Secrets and variables → Actions
2. Add these secrets:
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`
   - `AWS_REGION` (e.g., `us-east-1`)
   - `S3_BUCKET_NAME` (e.g., `podcaster-app`)
   - `CLOUDFRONT_DISTRIBUTION_ID` (optional, if using CloudFront)

3. Push to `main` branch → Automatic deployment!

---

## 🎯 Quick Decision Guide

| Question | Answer | Recommended Option |
|----------|--------|-------------------|
| Want fastest setup? | Yes | **Amplify** |
| Want lowest cost? | Yes | **S3 + CloudFront** |
| Need server-side features? | Yes | **EC2 + Nginx** |
| Want automatic deployments? | Yes | **Amplify** or **GitHub Actions** |
| Need custom domain? | Yes | All options support it |
| Need HTTPS? | Yes | All options support it |

---

## 🚀 Deploy Now (Choose One)

### Amplify (Fastest):
```bash
# Just push to GitHub and connect in Amplify Console
git push origin main
# Then go to https://console.aws.amazon.com/amplify/
```

### S3 (Manual):
```bash
# Build and deploy
npm run build
./aws-deploy.sh podcaster-app
```

### GitHub Actions (Automatic):
```bash
# Add secrets to GitHub, then push
git push origin main
# Deployment happens automatically!
```

---

## 📚 Need More Help?

- **Detailed instructions:** See `AWS-DEPLOYMENT.md`
- **Troubleshooting:** See "Troubleshooting" section in `AWS-DEPLOYMENT.md`
- **AWS CLI setup:** https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html

---

## ✅ Pre-Deployment Checklist

- [ ] AWS CLI installed and configured (`aws configure`)
- [ ] Code pushed to GitHub
- [ ] Build works locally (`npm run build`)
- [ ] Chosen deployment method
- [ ] Required AWS resources created (S3 bucket, etc.)
- [ ] Secrets configured (if using GitHub Actions)

---

**Ready to deploy? Pick an option above and let me know if you need help!** 🚀
