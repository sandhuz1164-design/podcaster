# 🚀 Upload PodCaster to GitHub - Step by Step Guide

## ✅ Pre-Upload Checklist

Before starting, make sure you have:
- [ ] GitHub account (sign up at https://github.com if needed)
- [ ] Git installed on your computer
- [ ] All project files ready (verified ✓)

---

## 📝 Step-by-Step Instructions

### Step 1: Initialize Git Repository

Open your terminal in the project folder and run:

```bash
# Initialize git repository
git init

# Add all files to staging
git add .

# Create first commit
git commit -m "Initial commit: PodCaster - Music & Podcast Platform"
```

**Expected output:**
```
Initialized empty Git repository in /path/to/podcaster/.git/
[main (root-commit) abc1234] Initial commit: PodCaster - Music & Podcast Platform
 35 files changed, 5000 insertions(+)
 create mode 100644 README.md
 create mode 100644 src/App.tsx
 ...
```

---

### Step 2: Create GitHub Repository

1. **Go to GitHub**: https://github.com/new

2. **Fill in repository details:**
   - **Repository name**: `podcaster` (or your preferred name)
   - **Description**: `🎵 Modern music & podcast streaming platform built with React, TypeScript, and Tailwind CSS`
   - **Visibility**: Choose `Public` or `Private`
   - **DO NOT** initialize with README, .gitignore, or license (we already have these)

3. **Click "Create repository"**

4. **Copy the repository URL** (it will look like):
   ```
   https://github.com/YOUR_USERNAME/podcaster.git
   ```

---

### Step 3: Connect Local Repository to GitHub

```bash
# Add GitHub as remote origin (replace with YOUR repository URL)
git remote add origin https://github.com/YOUR_USERNAME/podcaster.git

# Rename branch to main (if needed)
git branch -M main

# Push to GitHub
git push -u origin main
```

**Expected output:**
```
Enumerating objects: 45, done.
Counting objects: 100% (45/45), done.
Delta compression using up to 8 threads
Compressing objects: 100% (40/40), done.
Writing objects: 100% (45/45), 1.23 MiB | 2.34 MiB/s, done.
Total 45 (delta 5), reused 0 (delta 0)
To https://github.com/YOUR_USERNAME/podcaster.git
 * [new branch]      main -> main
Branch 'main' set up to track remote branch 'main' from 'origin'.
```

---

### Step 4: Verify Upload

1. **Go to your GitHub repository page**: `https://github.com/YOUR_USERNAME/podcaster`

2. **Refresh the page** and verify you can see:
   - ✅ README.md displayed at the top
   - ✅ All source files in the `src/` folder
   - ✅ Configuration files (package.json, tsconfig.json, etc.)
   - ✅ Deployment scripts (aws-deploy.sh, deploy-ec2.sh, etc.)
   - ✅ Documentation files (AWS-DEPLOYMENT.md, EC2-DEPLOYMENT.md, etc.)

3. **Check the commit history**:
   - Click on "Commits" to see your initial commit

---

## 🔧 Troubleshooting

### Issue: "fatal: remote origin already exists"

**Solution:**
```bash
# Remove existing remote
git remote remove origin

# Add new remote
git remote add origin https://github.com/YOUR_USERNAME/podcaster.git
```

---

### Issue: "Updates were rejected because the remote contains work that you do not have"

**Solution:**
```bash
# Force push (only if you're sure you want to overwrite)
git push -u origin main --force
```

⚠️ **Warning**: This will overwrite the remote repository. Only use if you created a new repo and accidentally initialized it with files.

---

### Issue: "Permission denied (publickey)"

**Solution:**
```bash
# Use HTTPS instead of SSH
git remote set-url origin https://github.com/YOUR_USERNAME/podcaster.git

# Try pushing again
git push -u origin main
```

---

### Issue: Files not showing on GitHub

**Solution:**
```bash
# Check git status
git status

# If files are untracked, add them
git add .
git commit -m "Add missing files"
git push origin main
```

---

### Issue: Large files warning

**Solution:**
The `.gitignore` file should exclude `node_modules/` and `dist/`. If you see large file warnings:

```bash
# Remove cached files
git rm -r --cached node_modules dist

# Commit the change
git commit -m "Remove node_modules and dist from tracking"

# Push
git push origin main
```

---

## 📋 Quick Command Reference

### Complete Upload Process (Copy-Paste Ready)

```bash
# 1. Initialize and commit
git init
git add .
git commit -m "Initial commit: PodCaster - Music & Podcast Platform"

# 2. Add remote and push (REPLACE YOUR_USERNAME with your actual GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/podcaster.git
git branch -M main
git push -u origin main
```

### After Upload - Common Commands

```bash
# Check status
git status

# View commit history
git log --oneline

# Pull latest changes
git pull origin main

# Make changes and push
git add .
git commit -m "Your commit message"
git push origin main
```

---

## 🎯 What's Next?

After successful upload to GitHub:

### 1. **Deploy to EC2** (if using AWS EC2)
```bash
# Follow the guide in EC2-DEPLOYMENT.md
ssh -i your-key.pem ec2-user@YOUR_EC2_IP
# Then run the setup and deployment scripts
```

### 2. **Setup Automated Deployment** (Optional)
- Add GitHub secrets for EC2 deployment
- Push to `main` branch will auto-deploy

### 3. **Share Your Project**
- Add the GitHub link to your portfolio
- Share on social media
- Add to your resume

---

## ✅ Success Indicators

You'll know the upload was successful when:
- ✅ You can see all files on GitHub web interface
- ✅ README.md is rendered properly
- ✅ Commit history shows your initial commit
- ✅ Repository URL works: `https://github.com/YOUR_USERNAME/podcaster`
- ✅ No error messages in terminal

---

## 🆘 Still Having Issues?

### Check Git Configuration
```bash
# View current config
git config --list

# Set your name and email (if not set)
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

### View Remote Repositories
```bash
git remote -v
```

### Check Branch
```bash
git branch
```

### Reset and Start Over (Last Resort)
```bash
# Remove git
rm -rf .git

# Start fresh
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/podcaster.git
git branch -M main
git push -u origin main --force
```

---

## 📞 Need Help?

If you're still stuck:
1. Check the error message carefully
2. Search for the error on Google or Stack Overflow
3. Check GitHub's documentation: https://docs.github.com/en/get-started
4. Open an issue on your own repository for tracking

---

## 🎉 Congratulations!

Once your code is on GitHub, you've completed a major milestone! Your PodCaster project is now:
- ✅ Version controlled
- ✅ Backed up in the cloud
- ✅ Ready for collaboration
- ✅ Ready for deployment
- ✅ Part of your developer portfolio

**Next step**: Deploy to your EC2 instance using the guide in `EC2-DEPLOYMENT.md`!
