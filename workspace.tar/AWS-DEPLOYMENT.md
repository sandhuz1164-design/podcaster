# 🚀 Deploy PodCaster to AWS

This guide provides step-by-step instructions to deploy your PodCaster app to AWS using different services.

---

## 📋 Prerequisites

1. **AWS Account** with appropriate permissions
2. **AWS CLI** installed and configured
   ```bash
   aws configure
   ```
3. **Node.js** and **npm** installed

---

## Option 1: AWS Amplify (Recommended - Easiest) ⭐

**Best for:** Automatic deployments from Git, CI/CD, easy setup

### Steps:

1. **Push your code to GitHub/GitLab/Bitbucket**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/podcaster.git
   git push -u origin main
   ```

2. **Go to AWS Amplify Console**
   - Visit: https://console.aws.amazon.com/amplify/
   - Click "New app" → "Host web app"

3. **Connect Your Repository**
   - Select your Git provider (GitHub/GitLab/Bitbucket)
   - Authorize AWS Amplify
   - Select your repository and branch (main)

4. **Configure Build Settings**
   - The `amplify.yml` file will be auto-detected
   - Framework preset: **Vite**
   - Build command: `npm run build`
   - Build output: `dist`

5. **Review and Deploy**
   - Click "Save and deploy"
   - Wait 2-3 minutes for deployment
   - Your app will be live at: `https://main.xxxxx.amplifyapp.com`

6. **Custom Domain (Optional)**
   - Go to "Domain management"
   - Add your custom domain
   - Follow DNS configuration steps

**Cost:** Free tier includes 1000 build minutes/month

---

## Option 2: S3 + CloudFront (Most Cost-Effective) 💰

**Best for:** Static sites, maximum control, lowest cost

### Step 1: Create S3 Bucket

```bash
# Create bucket (change region as needed)
aws s3api create-bucket \
    --bucket podcaster-app \
    --region us-east-1

# Enable static website hosting
aws s3 website s3://podcaster-app/ \
    --index-document index.html \
    --error-document index.html

# Apply bucket policy (update s3-policy.json with your bucket name)
aws s3api put-bucket-policy \
    --bucket podcaster-app \
    --policy file://s3-policy.json
```

### Step 2: Build and Deploy

```bash
# Build the project
npm run build

# Use the deployment script
chmod +x aws-deploy.sh
./aws-deploy.sh podcaster-app

# OR manually sync
aws s3 sync dist/ s3://podcaster-app/ --delete
```

### Step 3: Create CloudFront Distribution (For HTTPS + CDN)

1. **Go to CloudFront Console**
   - https://console.aws.amazon.com/cloudfront/

2. **Create Distribution**
   - Origin Domain: `podcaster-app.s3.us-east-1.amazonaws.com`
   - Origin Access: "Origin access control settings (recommended)"
   - Viewer protocol: "Redirect HTTP to HTTPS"
   - Default root object: `index.html`

3. **Update S3 Bucket Policy** (after creating OAC)
   ```json
   {
       "Version": "2012-10-17",
       "Statement": [
           {
               "Sid": "AllowCloudFrontServicePrincipal",
               "Effect": "Allow",
               "Principal": {
                   "Service": "cloudfront.amazonaws.com"
               },
               "Action": "s3:GetObject",
               "Resource": "arn:aws:s3:::podcaster-app/*",
               "Condition": {
                   "StringEquals": {
                       "AWS:SourceArn": "arn:aws:cloudfront::YOUR_ACCOUNT_ID:distribution/YOUR_DIST_ID"
                   }
               }
           }
       ]
   }
   ```

4. **Add Custom Error Response** (for React Router)
   - Error code: `403` and `404`
   - Response page: `/index.html`
   - HTTP response code: `200`

5. **Wait for Distribution** (5-10 minutes)

6. **Your site will be at:** `https://dxxxxxxxxx.cloudfront.net`

### Step 4: Add Custom Domain (Optional)

1. **Request SSL Certificate in ACM**
   ```bash
   # Go to AWS Certificate Manager
   # Request public certificate for your domain
   # Validate via DNS
   ```

2. **Add CNAME in CloudFront**
   - Go to CloudFront distribution
   - "General" tab → "Edit"
   - Add your domain: `app.yourdomain.com`
   - Select ACM certificate

3. **Update DNS**
   - Add CNAME record pointing to CloudFront distribution

**Cost:** ~$0.50-1.00/month for typical usage

---

## Option 3: EC2 + Nginx (Full Control) 🖥️

**Best for:** When you need server-side features or custom configurations

### Step 1: Launch EC2 Instance

```bash
# Use AWS Console or CLI to launch:
# - Amazon Linux 2023 or Ubuntu 22.04
# - t3.micro (free tier eligible)
# - Security group: Allow HTTP (80) and HTTPS (443)
```

### Step 2: Connect and Setup

```bash
# SSH into your instance
ssh -i your-key.pem ec2-user@your-ec2-ip

# Update system
sudo yum update -y  # Amazon Linux
# OR
sudo apt update && sudo apt upgrade -y  # Ubuntu

# Install Nginx
sudo yum install nginx -y  # Amazon Linux
# OR
sudo apt install nginx -y  # Ubuntu

# Start and enable Nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

### Step 3: Deploy Your App

```bash
# On your local machine, build the app
npm run build

# Copy files to EC2
scp -i your-key.pem -r dist/* ec2-user@your-ec2-ip:/tmp/

# On EC2, move files to web root
sudo mv /tmp/* /usr/share/nginx/html/
sudo chown -R nginx:nginx /usr/share/nginx/html/
```

### Step 4: Configure Nginx for React Router

```bash
sudo nano /etc/nginx/conf.d/podcaster.conf
```

Add this configuration:

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ $uri/ /index.html;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Don't cache index.html
    location = /index.html {
        expires -1;
        add_header Cache-Control "no-store, no-cache, must-revalidate";
    }
}
```

```bash
# Test and reload Nginx
sudo nginx -t
sudo systemctl reload nginx
```

### Step 5: Setup HTTPS with Let's Encrypt

```bash
# Install Certbot
sudo yum install certbot python3-certbot-nginx -y  # Amazon Linux
# OR
sudo apt install certbot python3-certbot-nginx -y  # Ubuntu

# Get SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Auto-renewal is configured automatically
```

**Cost:** ~$8-10/month (EC2 t3.micro after free tier)

---

## 🔄 Automated Deployment with GitHub Actions

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to AWS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Build
      run: npm run build
    
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: us-east-1
    
    - name: Deploy to S3
      run: |
        aws s3 sync dist/ s3://podcaster-app/ --delete
        aws cloudfront create-invalidation --distribution-id ${{ secrets.CLOUDFRONT_DIST_ID }} --paths "/*"
```

Add these secrets to your GitHub repo:
- `AWS_ACCESS_KEY_ID`
- `AWS_SECRET_ACCESS_KEY`
- `CLOUDFRONT_DIST_ID` (if using CloudFront)

---

## 📊 Comparison Table

| Feature | Amplify | S3 + CloudFront | EC2 + Nginx |
|---------|---------|-----------------|-------------|
| **Setup Difficulty** | Easy | Medium | Hard |
| **Cost** | Free tier | ~$0.50/mo | ~$8-10/mo |
| **CI/CD** | Built-in | Manual/GitHub Actions | Manual/GitHub Actions |
| **Custom Domain** | Free | Free (with ACM) | Free (with Let's Encrypt) |
| **HTTPS** | Automatic | Automatic | Manual setup |
| **Scalability** | Auto | Auto | Manual |
| **Best For** | Quick deploy | Production static sites | Full control |

---

## 🎯 My Recommendation

**For PodCaster (Static React App):**

1. **Quick & Easy:** Use **AWS Amplify** - deploy in 5 minutes
2. **Production & Cost-Effective:** Use **S3 + CloudFront** - ~$0.50/month
3. **Need Backend Features:** Use **EC2 + Nginx** - full control

---

## 🔧 Troubleshooting

### Issue: 403 Forbidden on S3
- Check bucket policy is applied
- Ensure "Block public access" is disabled for the bucket

### Issue: React Router not working (404 on refresh)
- S3: Set error document to `index.html`
- CloudFront: Add custom error response for 403/404 → `/index.html`
- Nginx: Use `try_files $uri $uri/ /index.html;`

### Issue: Assets not loading
- Check CORS headers if loading from different domain
- Verify file paths in `dist/` folder
- Clear CloudFront cache: `aws cloudfront create-invalidation --distribution-id DIST_ID --paths "/*"`

### Issue: Build fails on Amplify
- Check `amplify.yml` configuration
- Verify Node.js version compatibility
- Check build logs in Amplify console

---

## 📚 Additional Resources

- [AWS Amplify Documentation](https://docs.aws.amazon.com/amplify/)
- [S3 Static Website Hosting](https://docs.aws.amazon.com/AmazonS3/latest/userguide/WebsiteHosting.html)
- [CloudFront Developer Guide](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/)
- [React Deployment Best Practices](https://create-react-app.dev/docs/deployment/)

---

## 💡 Pro Tips

1. **Use CloudFront** even with S3 for HTTPS and global CDN
2. **Enable versioning** on S3 bucket for rollback capability
3. **Set up monitoring** with CloudWatch for your distribution
4. **Use Route 53** for DNS management if you need custom domains
5. **Implement CI/CD** with GitHub Actions for automated deployments
6. **Enable compression** in CloudFront (gzip/brotli) for faster loading

---

Need help with a specific deployment option? Let me know which one you're using and I can provide more detailed assistance!
