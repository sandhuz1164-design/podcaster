#!/bin/bash

# AWS S3 Deployment Script for PodCaster
# Usage: ./aws-deploy.sh [bucket-name]

set -e

# Configuration
BUCKET_NAME=${1:-"podcaster-app"}
REGION=${AWS_REGION:-"us-east-1"}
BUILD_DIR="dist"

echo "🚀 Deploying PodCaster to AWS S3..."
echo "Bucket: $BUCKET_NAME"
echo "Region: $REGION"
echo ""

# Check if AWS CLI is installed
if ! command -v aws &> /dev/null; then
    echo "❌ AWS CLI is not installed. Please install it first:"
    echo "   https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html"
    exit 1
fi

# Check if bucket exists
if ! aws s3api head-bucket --bucket "$BUCKET_NAME" 2>/dev/null; then
    echo "❌ Bucket '$BUCKET_NAME' does not exist or you don't have access to it."
    exit 1
fi

# Build the project
echo "📦 Building project..."
npm run build

# Sync files to S3
echo "📤 Uploading to S3..."
aws s3 sync $BUILD_DIR s3://$BUCKET_NAME \
    --delete \
    --region $REGION \
    --cache-control "public, max-age=31536000, immutable" \
    --exclude "index.html"

# Upload index.html with no-cache
echo "📄 Uploading index.html (no-cache)..."
aws s3 cp $BUILD_DIR/index.html s3://$BUCKET_NAME/index.html \
    --region $REGION \
    --cache-control "no-cache, no-store, must-revalidate" \
    --content-type "text/html"

echo ""
echo "✅ Deployment complete!"
echo ""
echo "🌐 Your site should be available at:"
echo "   https://$BUCKET_NAME.s3.$REGION.amazonaws.com"
echo ""
echo "💡 If you have CloudFront configured, invalidate the cache:"
echo "   aws cloudfront create-invalidation --distribution-id YOUR_DIST_ID --paths '/*'"
