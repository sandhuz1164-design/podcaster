# 🖥️ Deploy PodCaster to EC2 - Complete Guide

This guide will help you deploy PodCaster to your EC2 instance step-by-step.

---

## 📋 Prerequisites

- ✅ EC2 instance running (Amazon Linux 2023 or Ubuntu 22.04 recommended)
- ✅ SSH access to your EC2 instance
- ✅ Security group allows HTTP (port 80) and HTTPS (port 443)
- ✅ AWS CLI configured (optional, for advanced setup)

---

## 🚀 Quick Deploy (3 Steps)

### Step 1: Setup EC2 Instance

SSH into your EC2 instance and run the setup script:

```bash
# SSH into your EC2
ssh -i /path/to/your-key.pem ec2-user@YOUR_EC2_IP

# On EC2, download and run setup script
curl -O https://raw.githubusercontent.com/YOUR_USERNAME/podcaster/main/ec2-setup.sh
sudo bash ec2-setup.sh
```

**Or manually:**
```bash
# SSH into your EC2
ssh -i /path/to/your-key.pem ec2-user@YOUR_EC2_IP

# Update system
sudo yum update -y  # Amazon Linux
# OR: sudo apt update && sudo apt upgrade -y  # Ubuntu

# Install Nginx and Node.js
sudo yum install -y nginx git curl  # Amazon Linux
# OR: sudo apt install -y nginx git curl  # Ubuntu

# Install Node.js 18
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# Create app directory
sudo mkdir -p /var/www/podcaster
sudo chown -R $USER:$USER /var/www/podcaster
```

### Step 2: Configure Nginx

Create Nginx configuration:

```bash
sudo nano /etc/nginx/conf.d/podcaster.conf
```

Paste this configuration:

```nginx
server {
    listen 80;
    server_name _;  # Use your domain or keep _ for IP access
    
    root /var/www/podcaster;
    index index.html;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json application/javascript;

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    # Don't cache index.html
    location = /index.html {
        expires -1;
        add_header Cache-Control "no-store, no-cache, must-revalidate";
    }

    # React Router - serve index.html for all routes
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

Save and exit (Ctrl+X, Y, Enter).

```bash
# Test configuration
sudo nginx -t

# Start Nginx
sudo systemctl enable nginx
sudo systemctl start nginx
```

### Step 3: Deploy Your App

**Option A: Using deployment script (Recommended)**

On your local machine:

```bash
# Make script executable
chmod +x deploy-ec2.sh

# Deploy
./deploy-ec2.sh YOUR_EC2_IP /path/to/your-key.pem
```

**Option B: Manual deployment**

On your local machine:

```bash
# Build the project
npm run build

# Copy files to EC2
scp -i /path/to/your-key.pem -r dist/* ec2-user@YOUR_EC2_IP:/var/www/podcaster/
```

**Visit your app:**
```
http://YOUR_EC2_IP
```

---

## 🔒 Setup HTTPS (Let's Encrypt)

### Prerequisites
- Domain name pointing to your EC2 IP
- Port 443 open in security group

### Steps

```bash
# SSH into EC2
ssh -i /path/to/your-key.pem ec2-user@YOUR_EC2_IP

# Install Certbot
sudo yum install -y certbot python3-certbot-nginx  # Amazon Linux
# OR: sudo apt install -y certbot python3-certbot-nginx  # Ubuntu

# Update Nginx config with your domain
sudo nano /etc/nginx/conf.d/podcaster.conf
# Change: server_name _;
# To: server_name yourdomain.com www.yourdomain.com;

# Test and reload
sudo nginx -t
sudo systemctl reload nginx

# Get SSL certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Follow the prompts:
# - Enter email address
# - Agree to terms
# - Choose to redirect HTTP to HTTPS (recommended: 2)
```

**Auto-renewal:**
```bash
# Test auto-renewal
sudo certbot renew --dry-run

# Certbot automatically sets up a cron job for renewal
```

---

## 🔄 Automated Deployment with GitHub Actions

### Setup

1. **Add GitHub Secrets:**
   - Go to your GitHub repo → Settings → Secrets and variables → Actions
   - Add these secrets:
     - `EC2_HOST`: Your EC2 IP address
     - `EC2_USERNAME`: `ec2-user` (or `ubuntu`)
     - `EC2_SSH_KEY`: Your private SSH key (entire contents)

2. **Create workflow file:**

```bash
mkdir -p .github/workflows
nano .github/workflows/deploy-ec2.yml
```

Paste this:

```yaml
name: Deploy to EC2

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Build
      run: npm run build
    
    - name: Setup SSH
      run: |
        mkdir -p ~/.ssh
        echo "${{ secrets.EC2_SSH_KEY }}" > ~/.ssh/ec2_key
        chmod 600 ~/.ssh/ec2_key
    
    - name: Deploy to EC2
      run: |
        scp -i ~/.ssh/ec2_key -o StrictHostKeyChecking=no -r dist/* ${{ secrets.EC2_USERNAME }}@${{ secrets.EC2_HOST }}:/var/www/podcaster/
        ssh -i ~/.ssh/ec2_key -o StrictHostKeyChecking=no ${{ secrets.EC2_USERNAME }}@${{ secrets.EC2_HOST }} "sudo systemctl restart nginx"
```

3. **Push to GitHub:**
```bash
git add .
git commit -m "Add EC2 deployment workflow"
git push origin main
```

Now every push to `main` will automatically deploy to your EC2!

---

## 📊 Monitoring & Maintenance

### Check Nginx Status
```bash
sudo systemctl status nginx
```

### View Nginx Logs
```bash
# Error logs
sudo tail -f /var/log/nginx/error.log

# Access logs
sudo tail -f /var/log/nginx/access.log
```

### Check Disk Space
```bash
df -h
```

### Restart Nginx
```bash
sudo systemctl restart nginx
```

### Update SSL Certificate
```bash
sudo certbot renew
```

---

## 🛠️ Troubleshooting

### Issue: Can't access the site

**Check:**
1. Security group allows port 80 (HTTP) and 443 (HTTPS)
2. Nginx is running: `sudo systemctl status nginx`
3. Files are in correct location: `ls -la /var/www/podcaster/`
4. Nginx config is correct: `sudo nginx -t`

**Fix:**
```bash
# Restart Nginx
sudo systemctl restart nginx

# Check firewall
sudo firewall-cmd --list-all  # Amazon Linux
# OR: sudo ufw status  # Ubuntu
```

### Issue: 403 Forbidden

**Fix:**
```bash
# Check permissions
sudo chown -R $USER:$USER /var/www/podcaster
sudo chmod -R 755 /var/www/podcaster

# Check Nginx user
grep -E '^user' /etc/nginx/nginx.conf
# Should be: user nginx; (Amazon Linux) or user www-data; (Ubuntu)
```

### Issue: React Router not working (404 on refresh)

**Fix:**
Ensure Nginx config has:
```nginx
location / {
    try_files $uri $uri/ /index.html;
}
```

### Issue: Assets not loading

**Fix:**
```bash
# Check file permissions
ls -la /var/www/podcaster/assets/

# Rebuild and redeploy
npm run build
scp -i /path/to/key.pem -r dist/* ec2-user@YOUR_EC2_IP:/var/www/podcaster/
```

---

## 📈 Performance Optimization

### Enable Brotli Compression (Optional)

```bash
# Amazon Linux
sudo yum install -y nginx-mod-http-brotli-filter

# Ubuntu
sudo apt install -y libnginx-mod-http-brotli-filter
```

Add to Nginx config:
```nginx
brotli on;
brotli_comp_level 6;
brotli_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json application/javascript;
```

### Setup CloudFront CDN (Optional)

For global performance, add CloudFront in front of your EC2:

1. Create CloudFront distribution
2. Origin: Your EC2 IP or domain
3. Update DNS to point to CloudFront
4. Enable caching for static assets

---

## 🔐 Security Best Practices

### 1. Keep System Updated
```bash
# Amazon Linux
sudo yum update -y

# Ubuntu
sudo apt update && sudo apt upgrade -y
```

### 2. Setup Automatic Security Updates
```bash
# Amazon Linux
sudo yum install -y yum-cron
sudo systemctl enable yum-cron

# Ubuntu
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure --priority=low unattended-upgrades
```

### 3. Configure Firewall
```bash
# Amazon Linux
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --reload

# Ubuntu
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### 4. Disable SSH Password Authentication
```bash
sudo nano /etc/ssh/sshd_config
```

Set:
```
PasswordAuthentication no
PermitRootLogin no
```

```bash
sudo systemctl restart sshd
```

---

## 📝 Deployment Checklist

Before deploying:

- [ ] EC2 instance is running
- [ ] Security group allows ports 80 and 443
- [ ] SSH access works
- [ ] Nginx is installed and configured
- [ ] Node.js 18+ is installed
- [ ] App directory exists: `/var/www/podcaster`
- [ ] Build works locally: `npm run build`
- [ ] Files can be copied to EC2

After deploying:

- [ ] Site loads at http://YOUR_EC2_IP
- [ ] All routes work (refresh doesn't 404)
- [ ] Static assets load correctly
- [ ] HTTPS is configured (if using domain)
- [ ] Auto-renewal is set up for SSL

---

## 🎯 Quick Commands Reference

### Local Machine
```bash
# Build
npm run build

# Deploy
./deploy-ec2.sh YOUR_EC2_IP /path/to/key.pem

# Or manually
scp -i /path/to/key.pem -r dist/* ec2-user@YOUR_EC2_IP:/var/www/podcaster/
```

### On EC2
```bash
# Check Nginx status
sudo systemctl status nginx

# Restart Nginx
sudo systemctl restart nginx

# View logs
sudo tail -f /var/log/nginx/error.log

# Renew SSL
sudo certbot renew

# Check disk space
df -h
```

---

## 🆘 Need Help?

### Common Issues

**Can't SSH into EC2:**
- Check security group allows SSH (port 22)
- Verify SSH key permissions: `chmod 400 your-key.pem`
- Use correct username: `ec2-user` (Amazon Linux) or `ubuntu` (Ubuntu)

**Nginx won't start:**
```bash
# Check config
sudo nginx -t

# View error
sudo journalctl -u nginx
```

**Site shows old version after deploy:**
```bash
# Clear browser cache
# Or hard refresh: Ctrl+Shift+R (Windows/Linux) or Cmd+Shift+R (Mac)

# Restart Nginx
sudo systemctl restart nginx
```

---

## 📚 Additional Resources

- [Nginx Documentation](https://nginx.org/en/docs/)
- [Let's Encrypt Documentation](https://letsencrypt.org/docs/)
- [AWS EC2 Documentation](https://docs.aws.amazon.com/ec2/)
- [React Deployment Guide](https://create-react-app.dev/docs/deployment/)

---

## ✅ Success!

Your PodCaster app is now live on EC2! 🎉

**Next steps:**
1. Point your domain to the EC2 IP
2. Setup HTTPS with Let's Encrypt
3. Configure automated deployments with GitHub Actions
4. Monitor your app with CloudWatch

**Need help?** Check the troubleshooting section or open an issue on GitHub.
