#!/bin/bash
# Deploy PodCaster to EC2
# Usage: ./deploy-ec2.sh <EC2_IP> <SSH_KEY_PATH>

set -e

if [ -z "$1" ] || [ -z "$2" ]; then
    echo "❌ Usage: ./deploy-ec2.sh <EC2_IP> <SSH_KEY_PATH>"
    echo "Example: ./deploy-ec2.sh 54.123.45.67 ~/.ssh/my-key.pem"
    exit 1
fi

EC2_IP=$1
SSH_KEY=$2
EC2_USER="ec2-user"  # Change to "ubuntu" if using Ubuntu AMI
APP_DIR="/var/www/podcaster"

echo "🚀 Deploying PodCaster to EC2..."
echo "📍 Target: $EC2_USER@$EC2_IP"
echo ""

# Check SSH key exists
if [ ! -f "$SSH_KEY" ]; then
    echo "❌ SSH key not found: $SSH_KEY"
    exit 1
fi

# Build the project
echo "📦 Building project..."
npm run build

if [ ! -d "dist" ]; then
    echo "❌ Build failed - dist directory not found"
    exit 1
fi

echo "✅ Build successful"
echo ""

# Create remote directory
echo "📁 Creating remote directory..."
ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no $EC2_USER@$EC2_IP "sudo mkdir -p $APP_DIR && sudo chown -R $EC2_USER:$EC2_USER $APP_DIR"

# Backup current deployment (optional)
echo "💾 Backing up current deployment..."
ssh -i "$SSH_KEY" $EC2_USER@$EC2_IP "if [ -d $APP_DIR ]; then sudo mv $APP_DIR ${APP_DIR}_backup_$(date +%Y%m%d_%H%M%S); fi"

# Upload files
echo "📤 Uploading files to EC2..."
scp -i "$SSH_KEY" -o StrictHostKeyChecking=no -r dist/* $EC2_USER@$EC2_IP:$APP_DIR/

echo "✅ Files uploaded successfully"
echo ""

# Restart Nginx
echo "🔄 Restarting Nginx..."
ssh -i "$SSH_KEY" $EC2_USER@$EC2_IP "sudo systemctl restart nginx"

echo ""
echo "✅ Deployment Complete!"
echo ""
echo "🌐 Your app is live at: http://$EC2_IP"
echo ""
echo "🔒 To setup HTTPS (requires domain):"
echo "   ssh -i $SSH_KEY $EC2_USER@$EC2_IP"
echo "   sudo certbot --nginx -d yourdomain.com"
echo ""
