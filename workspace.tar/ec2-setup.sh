#!/bin/bash
# EC2 Setup Script for PodCaster
# Run this on your EC2 instance: sudo bash ec2-setup.sh

set -e

echo "🚀 Setting up PodCaster on EC2..."

# Update system
echo "📦 Updating system packages..."
if command -v yum &> /dev/null; then
    sudo yum update -y
    sudo yum install -y nginx git curl
elif command -v apt &> /dev/null; then
    sudo apt update && sudo apt upgrade -y
    sudo apt install -y nginx git curl
fi

# Install Node.js 18
echo "📦 Installing Node.js 18..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash - 2>/dev/null || \
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    
    if command -v yum &> /dev/null; then
        sudo yum install -y nodejs
    else
        sudo apt install -y nodejs
    fi
fi

echo "✅ Node.js version: $(node --version)"
echo "✅ npm version: $(npm --version)"

# Create app directory
echo "📁 Creating app directory..."
sudo mkdir -p /var/www/podcaster
sudo chown -R $USER:$USER /var/www/podcaster

# Configure Nginx
echo "⚙️ Configuring Nginx..."
sudo tee /etc/nginx/conf.d/podcaster.conf > /dev/null <<'EOF'
server {
    listen 80;
    server_name _;  # Change to your domain or keep _ for IP access
    
    root /var/www/podcaster;
    index index.html;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json application/javascript;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    # Don't cache index.html
    location = /index.html {
        expires -1;
        add_header Cache-Control "no-store, no-cache, must-revalidate";
    }

    # React Router - serve index.html for all routes
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Health check endpoint
    location /health {
        access_log off;
        return 200 'OK';
        add_header Content-Type text/plain;
    }
}
EOF

# Remove default Nginx config
sudo rm -f /etc/nginx/conf.d/default.conf 2>/dev/null || true
sudo rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true

# Test Nginx config
echo "🔍 Testing Nginx configuration..."
sudo nginx -t

# Start and enable Nginx
echo "🚀 Starting Nginx..."
sudo systemctl enable nginx
sudo systemctl restart nginx

# Setup firewall
echo "🔥 Configuring firewall..."
if command -v firewall-cmd &> /dev/null; then
    sudo firewall-cmd --permanent --add-service=http
    sudo firewall-cmd --permanent --add-service=https
    sudo firewall-cmd --reload
elif command -v ufw &> /dev/null; then
    sudo ufw allow 'Nginx Full'
    sudo ufw --force enable
fi

# Install Certbot for HTTPS (optional)
echo "🔒 Installing Certbot for HTTPS..."
if command -v yum &> /dev/null; then
    sudo yum install -y certbot python3-certbot-nginx
else
    sudo apt install -y certbot python3-certbot-nginx
fi

echo ""
echo "✅ EC2 Setup Complete!"
echo ""
echo "📋 Next Steps:"
echo "1. Build your app locally: npm run build"
echo "2. Copy files to EC2:"
echo "   scp -r dist/* ec2-user@YOUR_EC2_IP:/var/www/podcaster/"
echo "3. Visit: http://YOUR_EC2_IP"
echo ""
echo "🔒 For HTTPS (after pointing domain):"
echo "   sudo certbot --nginx -d yourdomain.com"
echo ""
